//Quest�o 07 
//Copie e execute o programa abaixo no Dev C++ e verifique as altera��es do n�mero de casas decimais de pontos flutuantes

# include <stdio.h>

int main ()

{
	printf ("Default: %f \n",3.1415169265);
	//usando apenas o %f, exibir� os numeros citados, mas n�o todos os numero, pede para imprimir um numero e apos a virgula mais 10 numeros
	//ele exibir� apenas 6 numeros, ficando da seguinte forma: 3.141517
	
    printf ("Uma casa: %.1f \n",3.1415169265);
    //usando %.1f, exibir� apenas uma casa apos a virgula, assim os numeros anteriores serao simplificado. Resultado 3.1
    
    printf ("Duas casas: %.2f \n",3.1415169265);
    //usando %.2f, exibir� 2 casa apos a virgula, ficando com 3.14, simplificafdo.
    
    printf ("Tr�s casas: %.3f \n",3.1415169265);
    //usando %.3f, exibir� 3 casas apos a virgula, e seguindo a simplifica��o de numeros, ficar� da seguinte forma: 3.142, o 2 � devido a simplifica��o
    //aumeta o valor na terceira casa apos a virgula
    
    printf ("Nota��o Cientifica: %e \n",3.1415169265);
    //a nota��o %e quer dizer pontencializa��o, seria 10 elevado a quantidade de casa, assim ficar� diferente do "Default" que nao aparece o numero total de 
    //numeros apos a virgula

}
