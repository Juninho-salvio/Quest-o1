//Quest�o 12 
//Fa�a um programa em C que calcule a quantidade de litros de combust�vel consumidos em uma viagem,
// sabendo-se que o carro tem autonomia de 12 km por litro de combust�vel.
// O programa dever� ler o tempo decorrido na viagem e a velocidade m�dia e aplicar as f�rmulas:

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

main()

{
	
	//D=Distancia percorrida em horas; T=Tempo decorrido; V=velocidade media; L=Litros de combustivel consumido
	float D, T, L;
	float V;
	
	printf("\nDigite o tempo decorrido do carro (em Horas)= \t");
	scanf("%f", &T);
	
	printf("\nDigite a velocidade media do carro= km/h \t");
	scanf("%f", &V);
	
	D = T*V;
	
	printf("\nDistancia percorrida eh=Km  \t%.2f\n", D);

	
	L = D/12;
	
	printf("\nLitros de combustivel consumido foi = \t%.2f\n", L);
	
}
