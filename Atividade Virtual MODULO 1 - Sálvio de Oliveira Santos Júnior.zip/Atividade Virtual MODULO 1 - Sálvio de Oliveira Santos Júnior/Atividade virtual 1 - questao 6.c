//Quest�o 06 
//Copie e execute o programa abaixo no Dev C++ e verifique as sa�das (resultados). 
//Comente a fun��o (prop�sito) da biblioteca conio.h, do comando clrscr e getch.

// Impress�o de n�meros reais 

#include <stdio.h> 
#include <conio.h> 

 //void main ()
 //para funcionar o programa, o VOID ter� que sair, ficando apenas o MAIN(). 
main()
{

    float NotaDaP1, NotaDaP2; 
	float Media; 
	 
//	clrscr();
	// CLRSCR necessita da biblioteca <canio.h>, a fun�ao dele � limpar 
	// Para que o programa funcione, a fun�ao CLRSCR tem que sair.
	 
    NotaDaP1 = 6.6;
	NotaDaP2 = 8.2;
	Media = (NotaDaP1 + NotaDaP2) / 2.0;
	 
	printf("Media Final : %.2f", Media); 
	getch(); 		
	//a funchao GETCH ele necessita da biblioteca <canio.h> , e nao recebe nenhum paramentro entre os parenteses,
	//realiza a captura do caractere  digitado no momento que voce digitar,
	//nao consegue vizualizar o caracter que voce digitou, ele simplismente captura
	//como no exemplo: para que eu pudesse usar o GETCH no programa, poderia colocar: NotaDaP1 = getch(), ele nao iria vizualizar o 6.6
	//para vizualizar, usaria um printf = ( "%f", NotaDaP1), assim parece o numero ou caractere apresentado.
 
 
 			// para que funcione o programa correto, temos que retirar o VOID, e o comando CLRSCR, assim nosso programa funciona corretamente, 
 			//Mostrando a media pedida, o getch nao tera nenhuma altera��o nesse programa.
}
