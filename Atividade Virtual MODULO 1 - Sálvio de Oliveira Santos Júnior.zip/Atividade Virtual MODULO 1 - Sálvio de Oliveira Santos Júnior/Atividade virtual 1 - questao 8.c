//Quest�o 08 
// Fa�a um programa em C que leia o valor de um produto, o percentual do desconto desejado e 
//imprima o valor do desconto e o valor do produto subtraindo o desconto.

#include<stdio.h>
#include<stdlib.h>

 main()

{
	//Pro � o valor do produto, Desc � o valor do desconto em por cento, vlrDesc � o valor total com desconto e vlrReal � o valor que foi dado em Real.
	float Prod, Desc, vlrDesc, vlrReal;
	
	printf("\nDigite o valor do produto: R$ \t");
	scanf("%f", &Prod);
	
	//coloca o valor do desconto referente ao produto
	printf("\nDigite quantos por cento de desconto:  \t ");
	scanf("%f", &Desc);
	
	vlrDesc = Prod - (Prod * (Desc / 100));
	
	vlrReal = Prod - vlrDesc;
	
	printf("\nDesconto em Real eh: R$ \t%.2f\n", vlrReal);
	
	printf("\nValor total do produto com desconto: R$ \t%.2f\n", vlrDesc);
		
}
