//Quest�o 01 
//    Fa�a um programa em C que imprima o seu nome.

#include<stdio.h>

main()

{
	
	//N�o usei o acento no primeiro a e na letra u devido a forma imprimida saiu estranho
	printf("\nSalvio de Oliveira Santos Junior \n");
	
	
	
}
