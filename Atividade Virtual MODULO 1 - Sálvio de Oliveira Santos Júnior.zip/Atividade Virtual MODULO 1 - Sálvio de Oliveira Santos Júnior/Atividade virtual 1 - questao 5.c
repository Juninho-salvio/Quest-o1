//Quest�o 05 
// Fa�a um programa em C que leia um n�mero inteiro e imprima o seu antecessor e o seu sucessor.

#include<stdio.h>

main()

{
	
	int n;
	
	printf("\nDigite o numero: ");
	scanf("%d", &n);
	
	printf("\nNumero Antecessor:  \t%d \nnumero sucessor:  \t%d\n", n-1, n+1);
	
	
}
