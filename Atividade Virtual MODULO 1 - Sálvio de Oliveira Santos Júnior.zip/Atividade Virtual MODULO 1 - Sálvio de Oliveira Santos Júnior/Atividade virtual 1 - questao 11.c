//Quest�o 11  
//Construa um algoritmo que tendo como entrada dois pontos quaisquer do plano P(x1,y1) e Q(x2,y2), 
//imprima a dist�ncia entre eles. A f�rmula da dist�ncia �:

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

main()

{
	float x1, x2, y1, y2, raiz;
	
	printf("\nNo ponto P, vamos escrevre o x1: \n");
	scanf("%f", &x1);
	
	printf("\nNo ponto P, vamos escrevre o y1: \n");
	scanf("%f", &y1);
	
	printf("\nNo ponto Q, vamos escrevre o x2: \n");
	scanf("%f", &x2);
	
	printf("\nNo ponto Q, vamos escrevre o y2: \n");
	scanf("%f", &y2);
	
	raiz = sqrt( pow((x2 - x1),2) + pow((y2 - y1),2));
	
	printf("\n\nA Distancia entre os dois pontos eh: \t%.2f\n ", raiz);
	
}
