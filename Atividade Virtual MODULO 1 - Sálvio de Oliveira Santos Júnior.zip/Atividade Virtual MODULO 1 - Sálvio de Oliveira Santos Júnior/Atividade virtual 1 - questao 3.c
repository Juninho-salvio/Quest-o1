//Quest�o 03 
//Fa�a um programa o qual o usu�rio digite seu peso e o de mais duas pessoas, imprima os valores digitados.

#include<stdio.h>

main()

{
	
	//Citei o usuario como pessoa 1
	float pessoa1, pessoa2, pessoa3;
	
	printf("\n\nDigite o peso da primeira pessoa: \t");
	scanf("%f, pessoa1");
	
	printf("\nDigite o peso da segunda pessoa: \t");
	scanf("%f, pessoa2");
	
	printf("\nDigite o peso da terceira pessoa: \t");
	scanf("%f, pessoa3");
	
}
