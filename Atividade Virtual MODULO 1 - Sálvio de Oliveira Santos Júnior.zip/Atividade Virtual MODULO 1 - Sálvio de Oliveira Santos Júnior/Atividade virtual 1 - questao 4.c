//Quest�o 04 
// Fa�a um programa em C que imprima o produto dos valores 22 e 18.

#include <stdio.h>

main()

{
	int resultado;
	resultado = 22*18;
	
	printf("\n\nResultado: \t%d\n", resultado);
	
}
