//Quest�o 02 
// Fa�a um programa que imprima na primeira linha seu nome, na segunda sua idade e na terceira sua altura.

#include<stdio.h>

main()

{
	printf("\nSalvio de Oliveira Santos Junior \n");
	printf("Idade 37 anos\n");
	printf("Altura 1 metro e 80 centimetros \n");
	
}
