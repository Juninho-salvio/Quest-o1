//Quest�o 09 
// Fa�a um programa em C que leia um n�mero e ap�s a leitura, calcule e imprima a raiz quadrada deste n�mero. 
//Obs: neste programa dever� ser utilizada uma fun��o para este c�lculo que est� presente na biblioteca math <math.h>.

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

main()

{
	float nun, raiz;
	
	//num1 � o numero que ser� calculado a raiz quadrada
	printf("\n\nEscreva um numero: \t");
	scanf("%f", &nun);
	
	raiz = sqrt(nun);
	
	printf("\n\nA raiz quadrada do numero e= %.2f\n", raiz);
	
	
}
