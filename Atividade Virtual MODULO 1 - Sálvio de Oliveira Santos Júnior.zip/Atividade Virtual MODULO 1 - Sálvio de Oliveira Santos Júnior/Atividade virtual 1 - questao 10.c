//Quest�o 10 
//Fa�a um programa em C que calcule o valor de uma presta��o em atraso. Para isso, o programa deve ler o valor da presta��o vencida,
//a taxa peri�dica de juros e o per�odo de atraso. Ao final, o programa deve imprimir o valor da presta��o atrasada, 
//o per�odo de atraso, os juros que ser�o cobrados pelo per�odo de atraso, o valor da presta��o acrescido dos juros. Considere juros simples

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

main()

{
	//Dados para come�ar o programa
 	float vPrestacao, tj, juros, Valor;
 	int Atraso;
 	
 	//Cria��o do valor da presta��o
 	printf("\nValor da prestacao vencida: R$ ");
 	scanf("%f", &vPrestacao);
 	
 	//taxa de juros em por centos
 	printf("\nTaxa de juros: ");
 	scanf("%f", &tj);
 	
 	//Dias atrasados
 	printf("\nPeriodo de atraso: ");
 	scanf("%d", &Atraso);
 	
 	juros = ((vPrestacao * (tj / 100)) * Atraso);
 	
 	Valor = vPrestacao + juros;
 	
 	printf("\n\n\nValor prestacao: R$ %.2f \n", vPrestacao);
 	
 	printf("\n\nPeriodo de atraso:  %d \n", Atraso);
 	
 	printf("\n\nJuros a ser cobrados: R$ %.2f \n", juros);
 	
 	printf("\n\nValor da prestacao com juros: R$ %.2f\n", Valor);
 	
 	
}
